package com.walmart.mx.controls.controller;

import java.time.LocalDateTime;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.mx.controls.entity.Order;
import com.walmart.mx.controls.repository.IOrderRepository;

@RestController
public class OrderController {

	@Autowired
	private IOrderRepository orderRepository;

	@GetMapping("/api/orders/{id}")
	public Order getOrder(@PathVariable String id) {
		Order data=null;
		try {
			data=orderRepository.findById(id).orElse(null);
			Order order=new Order();
			order.setDescription("Hari");
			//order.setTimestamp(new Date());
			orderRepository.save(order);
		} catch (Exception e) {
			e.printStackTrace();
		}		
		
		return data;
	}

}
