package com.walmart.mx.controls.repository;

import org.springframework.stereotype.Repository;

import com.google.cloud.spring.data.spanner.repository.SpannerRepository;
import com.walmart.mx.controls.entity.Order;

@Repository
public interface IOrderRepository extends SpannerRepository<Order, String> {

}
