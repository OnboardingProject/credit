package com.walmart.mx.controls;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.google.cloud.spring.data.spanner.repository.config.EnableSpannerRepositories;

@SpringBootApplication
@EnableSpannerRepositories
public class MxCreditoControlsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MxCreditoControlsApplication.class, args);
	}

}
