package com.walmart.mx.firstdatainput.job;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.stereotype.Component;

import com.walmart.mx.firstdatainput.bo.Transaction;

import lombok.extern.slf4j.Slf4j;
@Component
@Slf4j
public class MyProcessListener implements ItemProcessListener<Transaction, Transaction> {

    @Override
    public void beforeProcess(Transaction myEntityA ) {}

    @Override
    public void afterProcess(Transaction myEntityA, Transaction myEntityB) {
    	
    	log.info("Process completed");
    }

    @Override
    public void onProcessError(Transaction myEntityA, Exception e) {
    	log.error("Error in process"+myEntityA);
    }
}