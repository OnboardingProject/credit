package com.walmart.mx.firstdatainput.entity;

import com.google.cloud.spring.data.spanner.core.mapping.Column;
import com.google.cloud.spring.data.spanner.core.mapping.Table;

import lombok.Data;

@Table(name = "credit_sales")
@Data
public class CreditSales {

	@Column(name = "sales_id")
	private int salesId;

	@Column(name = "sales_amount")
	private double salesAmount;

	@Column(name = "sale_by")
	private String saleBy;

	@Column(name = "sale_day")
	private String saleDate;

	@Column(name = "bill_print")
	private boolean isPrinted;

}
