package com.walmart.mx.firstdatainput.job;

import org.springframework.batch.core.step.skip.NonSkippableReadException;
import org.springframework.batch.core.step.skip.SkipLimitExceededException;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.validation.BindException;

import com.walmart.mx.firstdatainput.exception.CustomException;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class CustomSkipPolicy implements SkipPolicy {

	@Override
	public boolean shouldSkip(Throwable t, long skipCount) throws SkipLimitExceededException {
		
        if (t instanceof FlatFileParseException) {
        	log.info("Exception {}", ((FlatFileParseException) t).getInput());
        	return true;
		}if (t instanceof Exception || t instanceof CustomException) { 
			return true; // Skip this line } return
		  }
		 
		return true;
	}
}