package com.walmart.mx.firstdatainput.job;

import java.math.BigDecimal;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;

import com.walmart.mx.firstdatainput.bo.Transaction;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TranasctionDataMapper implements FieldSetMapper<Transaction> {
	public Transaction mapFieldSet(FieldSet fieldSet) {
		Transaction transaction = new Transaction();
		String line = fieldSet.readString(0);
		try {

			transaction.setTransactionDate(line.substring(0, 9));
			transaction.setTransactionType(line.substring(10, 13));
			transaction.setTransactionAmt(new BigDecimal(line.substring(14, 16)));
			transaction.setAuthorizationNmbr(Integer.parseInt(line.substring(17)));
		} catch (Exception e) {
			log.error("Incorrect data format" + line);
		}

		return transaction;
	}
}