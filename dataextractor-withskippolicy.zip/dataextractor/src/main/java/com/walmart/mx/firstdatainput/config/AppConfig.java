package com.walmart.mx.firstdatainput.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.google.cloud.spanner.TransactionContext;
import com.google.cloud.spring.data.spanner.core.SpannerTransactionManager;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableTransactionManagement
public class AppConfig {

	@Bean
	@Primary
	public DataSource dataSource() {
		HikariDataSource dataSource = new HikariDataSource();
		dataSource.setDriverClassName("org.h2.Driver");
		dataSource.setJdbcUrl("jdbc:h2:mem:testdb");
		dataSource.setUsername("sa");
		dataSource.setPassword("password");
		return dataSource;
	}

	@Bean(name = "spannerdatasource")
	public DataSource spannerDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.google.cloud.spanner.jdbc.JdbcDriver");
		dataSource.setUrl(
				"jdbc:cloudspanner:/projects/spanner-391007/instances/credito/databases/credito_db?credentials=C:\\Users\\154103\\Desktop\\Batch-Git\\dataextractor - Spanner\\src\\main\\resources\\cred.json");
		return dataSource;
	}

	@Bean
	@Primary
	public PlatformTransactionManager primaryTransactionManager() {
		return new DataSourceTransactionManager(dataSource());
	}
	
	

}
