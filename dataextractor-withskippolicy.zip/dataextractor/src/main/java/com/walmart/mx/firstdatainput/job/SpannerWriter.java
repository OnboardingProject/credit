package com.walmart.mx.firstdatainput.job;

import java.util.UUID;

import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.cloud.spring.data.spanner.core.SpannerTemplate;
import com.walmart.mx.firstdatainput.bo.Transaction;
import com.walmart.mx.firstdatainput.entity.CreditSales;
import com.walmart.mx.firstdatainput.exception.CustomException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SpannerWriter implements ItemWriter<Transaction> {

	@Autowired
	private SpannerTemplate template;

	@Override
	public void write(Chunk<? extends Transaction> chunk) throws Exception {

		log.info("Writing data into credit sales table");
		chunk.getItems().forEach(item -> {
			
			if(item.getAuthorizationNmbr()==1235) {
	        	 throw new CustomException("Failed");
	         }
			
			CreditSales saleObj = new CreditSales();
			saleObj.setSalesAmount(item.getTransactionAmt().doubleValue());
			UUID uuid = UUID.randomUUID();
			int saleId = (int) uuid.getMostSignificantBits();
			saleObj.setSalesId(saleId);
			template.insert(saleObj);
		});

	}

}
