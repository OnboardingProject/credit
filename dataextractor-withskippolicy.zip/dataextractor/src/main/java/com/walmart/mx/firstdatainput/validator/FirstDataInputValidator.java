package com.walmart.mx.firstdatainput.validator;

public class FirstDataInputValidator {

}
