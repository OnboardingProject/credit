package com.walmart.mx.firstdatainput.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public abstract class AbstractSequenceGenerator {

	static final String SEQUENCES_TABLE = "sequences";
	  static final String NEXT_VALUE_COLUMN = "next_value";
	  static final String SEQUENCE_NAME_COLUMN = "name";
	  protected final String sequenceName;

	  public AbstractSequenceGenerator(String sequenceName) {
	    this.sequenceName = sequenceName;
	  }

	  /**
	   * Gets the next value from the sequence.
	   */
	  public abstract long getNext();

	  // [START getNextInBackground]
	  protected static final ExecutorService executor = Executors.newCachedThreadPool();

	  /**
	   * Gets the next value using a background thread - to be used when inside a transaction to avoid
	   * Nested Transaction errors.
	   */
	  public long getNextInBackground() throws Exception {
	    return executor.submit(this::getNext).get();
	  }
	
}
