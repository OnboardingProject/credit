package com.walmart.mx.firstdatainput.job;

import org.springframework.batch.core.SkipListener;
import org.springframework.batch.item.file.LineCallbackHandler;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Component
public class MySkipListener implements SkipListener<String, String>{

	@Override
	public void onSkipInRead(Throwable t) {
		log.info("Exception while read"+t.getMessage());
	}

	@Override
	public void onSkipInWrite(String item, Throwable t) {
		log.info("Exception while write"+item);
	}

	@Override
	public void onSkipInProcess(String item, Throwable t) {
		log.info("Exception while process"+item);
	}

	
}