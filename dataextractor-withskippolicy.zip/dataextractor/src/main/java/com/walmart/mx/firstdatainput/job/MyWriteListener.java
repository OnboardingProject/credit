package com.walmart.mx.firstdatainput.job;

import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.item.Chunk;
import org.springframework.stereotype.Component;

import com.walmart.mx.firstdatainput.bo.Transaction;
@Component
public class MyWriteListener implements ItemWriteListener<Transaction> {

	@Override
	public void beforeWrite(Chunk<? extends Transaction> items) {
	}

	@Override
	public void afterWrite(Chunk<? extends Transaction> items) {
	}

	@Override
	public void onWriteError(Exception exception, Chunk<? extends Transaction> items) {
		System.out.println("Error in items"+items.getItems().toString()); 
	}
}