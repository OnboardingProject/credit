package com.walmart.mx.firstdatainput.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.interceptor.DefaultTransactionAttribute;

import com.walmart.mx.firstdatainput.bo.Transaction;
import com.walmart.mx.firstdatainput.job.CustomSkipPolicy;
import com.walmart.mx.firstdatainput.job.FileDeletingTasklet;
import com.walmart.mx.firstdatainput.job.JobCompletionNotificationListener;
import com.walmart.mx.firstdatainput.job.MyProcessListener;
import com.walmart.mx.firstdatainput.job.MyWriteListener;
import com.walmart.mx.firstdatainput.job.SpannerWriter;
import com.walmart.mx.firstdatainput.job.TransactionDataProcessor;

import lombok.extern.slf4j.Slf4j;

/**
 * @author 154103
 *
 */
@Configuration
@Slf4j
public class BatchConfigurationPositionbased {

	@Autowired
	@Qualifier("primaryTransactionManager") // Reference the primary transaction manager
	private PlatformTransactionManager transactionManager;

	// tag::readerwriterprocessor[]
	@Bean
	public FlatFileItemReader<Transaction> readerpob() {
		FlatFileItemReader<Transaction> itemReader = new FlatFileItemReader<>();
		DefaultLineMapper<Transaction> lineMapper = new DefaultLineMapper<>();
		lineMapper.setLineTokenizer(fixedLengthTokenizer());
		lineMapper.setFieldSetMapper(new BeanWrapperFieldSetMapper<Transaction>() {
			{
				setTargetType(Transaction.class);
			}
		});
		itemReader.setLinesToSkip(1);

		itemReader.setLineMapper(lineMapper);
		itemReader.setResource(new FileSystemResource("resources/transactions3.txt"));
		return itemReader;

	}

	@Bean
	public TransactionDataProcessor processorpob() {
		return new TransactionDataProcessor();
	}

	@Bean
	public SpannerWriter writerpob() {
		return new SpannerWriter();
	}

	@Bean(name = "personJob1")
	public Job importUserJob(JobRepository jobRepository, JobCompletionNotificationListener listener, Step step11,
			Step step13) {

		return new JobBuilder("importUserJob", jobRepository).incrementer(new RunIdIncrementer()).flow(step11)
				.next(step13).end().build();
	}

	@Bean
	public Step step11(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			SpannerWriter writerpob) {
		log.info("Inside step1");
		return new StepBuilder("step11", jobRepository).<Transaction, Transaction>chunk(10, transactionManager)
				.reader(readerpob()).processor(processorpob()).listener(new MyProcessListener()).writer(writerpob)
				.listener(new MyWriteListener()).faultTolerant().skipPolicy(new CustomSkipPolicy()).build();
	}

	@Bean
	public FileDeletingTasklet fileDeletingTaskletpob() {
		return new FileDeletingTasklet(new FileSystemResource("target/test-inputs"));
	}

	@Bean
	public Step step12(JobRepository jobRepository, PlatformTransactionManager transactionManager,
			SpannerWriter writerpob) {
		return new StepBuilder("step12", jobRepository).<Transaction, Transaction>chunk(10, transactionManager)
				.reader(readerpob()).processor(processorpob()).writer(writerpob).build();
	}

	@Bean
	public Step step13(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
		DefaultTransactionAttribute attribute = new DefaultTransactionAttribute();
		attribute.setPropagationBehavior(Propagation.REQUIRED.value());
		attribute.setIsolationLevel(Isolation.DEFAULT.value());
		attribute.setTimeout(30);
		return new StepBuilder("step13", jobRepository).tasklet(fileDeletingTaskletpob(), transactionManager)
				.transactionAttribute(attribute).build();
	}

	@Bean
	public FixedLengthTokenizer fixedLengthTokenizer() {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setNames("transactionDate", "transactionType", "transactionAmt", "authorizationNmbr");
		tokenizer.setColumns(new Range[] { new Range(1, 10), new Range(11, 14), new Range(15, 17), new Range(18) });
		tokenizer.setStrict(false);
		return tokenizer;
	}

}
