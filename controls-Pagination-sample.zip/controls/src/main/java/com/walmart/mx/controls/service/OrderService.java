package com.walmart.mx.controls.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.cloud.spanner.Statement;
import com.google.cloud.spring.data.spanner.core.SpannerPageableQueryOptions;
import com.google.cloud.spring.data.spanner.core.SpannerTemplate;
import com.walmart.mx.controls.entity.Order;
//import com.walmart.mx.controls.repository.CustomSpannerTemplate;
import com.walmart.mx.controls.repository.IOrderRepository;

@Service
public class OrderService {

	@Autowired
	private IOrderRepository orderRepository;


	@Autowired
	private SpannerTemplate temp;

	public List<Order> getPaginatedData(int offset, long pageNo) {
		SpannerPageableQueryOptions op = new SpannerPageableQueryOptions().setLimit(offset).setOffset(offset * pageNo);
		Statement.Builder buildStatement = Statement.newBuilder(
				"SELECT * FROM orders order by description asc limit " + offset + " offset " + (offset * pageNo));
		List<Order> orders = temp.query(Order.class, buildStatement.build(), op);
		return orders;

	}

	public Order getOrderByID(long id) throws Exception {

		/*
		 * Sample insert code UUID uuid = UUID.randomUUID();
		 * 
		 * Order order = new Order(); order.setDescription("Test1");
		 * order.setId(uuid.getMostSignificantBits()); orderRepository.save(order); //
		 * temp.insert(order);
		 */

		return orderRepository.findById(id).orElseThrow(RuntimeException::new);

	}

}
