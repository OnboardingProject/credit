package com.walmart.mx.controls.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.walmart.mx.controls.entity.Order;
import com.walmart.mx.controls.service.OrderService;

import lombok.extern.slf4j.Slf4j;

@RestController
public class OrderController {

	@Autowired
	private OrderService orderService;

	@GetMapping("/api/orders/{id}")
	public ResponseEntity<Order> getOrder(@PathVariable long id) throws Exception {
		Order data = null;
		data = orderService.getOrderByID(id);
		return ResponseEntity.ok(data);
	}

	@GetMapping("/api/orders/{pageNo}/{offset}")
	public ResponseEntity<List<Order>> getOrderPaginated(@PathVariable int offset, @PathVariable int pageNo) {
		List<Order> data = null;
		data = orderService.getPaginatedData(offset, pageNo);
		return ResponseEntity.ok(data);
	}

}
