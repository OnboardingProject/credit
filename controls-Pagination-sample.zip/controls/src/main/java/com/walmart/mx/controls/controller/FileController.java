package com.walmart.mx.controls.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.walmart.mx.controls.entity.Order;
@RestController
public class FileController {

	@Value("${gcp.bucket.name}")
	private String bucketName;

	@Autowired
	Storage storage;

	@PostMapping("upload")
	public String getOrder(@RequestParam MultipartFile file) {

		try {

			BlobId blobId = BlobId.of(bucketName, file.getOriginalFilename());
			BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType(file.getContentType()).build();
			Blob blob = storage.create(blobInfo, file.getBytes());

			// temp.insert(order);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "Created";
	}

}
