package com.walmart.mx.controls.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.google.cloud.spring.data.spanner.repository.SpannerRepository;
import com.google.cloud.spring.data.spanner.repository.query.Query;
import com.walmart.mx.controls.entity.Order;

@Repository
public interface IOrderRepository extends SpannerRepository<Order, Long> {

	@Query("INSERT INTO credit_sales1(description) values(@fragment);")
	Order getByQuery(@Param("fragment") String firstNameFragment);
}
