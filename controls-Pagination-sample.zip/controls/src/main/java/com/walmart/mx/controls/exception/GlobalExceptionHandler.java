package com.walmart.mx.controls.exception;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(org.springframework.web.bind.MissingServletRequestParameterException.class)
	public ResponseEntity<Object> missingServletRequestParameterException(
			org.springframework.web.bind.MissingServletRequestParameterException ex, WebRequest request) {
		log.error("Exception in {}", request.getContextPath(), ex);
		Map<String, Object> body = new LinkedHashMap<>();
		body.put("Timestamp", LocalDateTime.now());
		body.put("Status", HttpStatus.BAD_REQUEST);
		List<String> details = new ArrayList<>();
		details.add(ex.getMessage());
		body.put("errors", details);
		return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<Object> constraintViolationExceptio(ConstraintViolationException ex, WebRequest request) {
		log.error("Exception in {}", request.getContextPath(), ex);
		Map<String, Object> body = new LinkedHashMap<>();
		body.put("Timestamp", LocalDateTime.now());
		body.put("Status", HttpStatus.BAD_REQUEST);
		List<String> details = new ArrayList<>();
		details.add(ex.getMessage());
		body.put("errors", details);
		return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(CustomException.class)
	public ResponseEntity<Object> customExceptionHandler(CustomException ex, WebRequest request) {
		log.error("Exception in {}", request.getContextPath(), ex);
		Map<String, Object> body = new LinkedHashMap<>();
		body.put("Timestamp", LocalDateTime.now());
		body.put("Status", HttpStatus.BAD_REQUEST);
		List<String> details = new ArrayList<>();
		details.add(ex.getMessage());
		body.put("errors", details);
		return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
	}

}