# dataextractor
Extracting data from a text file with delimited data, delimiter used here is "@"
