package com.walmart.mx.controls.controller;

import java.time.LocalDateTime;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.google.cloud.spring.data.spanner.core.SpannerTemplate;
import com.walmart.mx.controls.entity.Order;
import com.walmart.mx.controls.repository.IOrderRepository;

@RestController
public class OrderController {

	@Autowired
	private IOrderRepository orderRepository;
	
	@Autowired
	private SpannerTemplate temp;

	@GetMapping("/api/orders/{id}")
	public Order getOrder(@PathVariable String id) {
		Order data=null;
		try {
			data=orderRepository.findById(0L).orElse(null);
			Order order=new Order();
			order.setDescription("Test1");
			//order.setTimestamp(new Date());
			orderRepository.save(order);
			//temp.insert(order);
		} catch (Exception e) {
			e.printStackTrace();
		}		
		
		return data;
	}

}
