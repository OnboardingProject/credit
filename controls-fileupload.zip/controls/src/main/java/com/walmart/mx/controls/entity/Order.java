package com.walmart.mx.controls.entity;

import com.google.cloud.spring.data.spanner.core.mapping.PrimaryKey;
import com.google.cloud.spring.data.spanner.core.mapping.Table;

import lombok.Data;

@Table(name = "credit_sales1")
@Data
public class Order {

	@PrimaryKey
	private Long id;

	private String description;

}