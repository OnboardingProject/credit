/*
 * package com.walmart.mx.controls.util;
 * 
 * import java.io.IOException; import java.io.InputStream; import
 * java.nio.file.Path; import java.util.ArrayList; import java.util.List;
 * 
 * import org.springframework.stereotype.Component;
 * 
 * import com.google.api.services.storage.Storage; import
 * com.google.cloud.storage.BlobId; import com.google.cloud.storage.BlobInfo;
 * import com.google.cloud.storage.StorageOptions; import
 * com.jcraft.jsch.ChannelSftp; import com.jcraft.jsch.JSch; import
 * com.jcraft.jsch.JSchException; import com.jcraft.jsch.Session; import
 * com.jcraft.jsch.SftpException;
 * 
 * @Component public class SftpUtil {
 * 
 * private ChannelSftp setupJsch() throws JSchException { List<Integer> arr=new
 * ArrayList<Integer>(); JSch jsch = new JSch();
 * jsch.setKnownHosts("/Users/john/.ssh/known_hosts"); Session jschSession =
 * jsch.getSession("SSH connection username", "SFTP host name");
 * jschSession.setPassword("SSH connection password"); jschSession.connect();
 * return (ChannelSftp) jschSession.openChannel("sftp");
 * 
 * 
 * 
 * }
 * 
 * 
 * public boolean uploadFileUsingSSH() throws JSchException, SftpException,
 * IOException {
 * 
 * ChannelSftp channelSftp = setupJsch(); channelSftp.connect(); String
 * localFile = "src/main/resources/sample.txt"; String remoteDir =
 * "remote_sftp_test/"; channelSftp.put(localFile, remoteDir + "jschFile.txt");
 * 
 * channelSftp.exit();
 * 
 * 
 * String remoteFile = "welcome.txt"; String localDir = "src/main/resources/";
 * 
 * 
 * channelSftp.get(remoteFile, localDir + "jschFile.txt");
 * 
 * 
 * String bucketName = "my-unique-bucket"; String blobName = "my-blob-name";
 * BlobId blobId = BlobId.of(bucketName, blobName); BlobInfo blobInfo =
 * BlobInfo.newBuilder(blobId).setContentType("text/plain").build(); Blob blob =
 * storage.create(blobInfo);
 * 
 * 
 * InputStream inputStreamFromRemote=channelSftp.get(localDir + "jschFile.txt");
 * com.google.cloud.storage.Storage storage =
 * StorageOptions.getDefaultInstance().getService(); BlobInfo blobInfo
 * =BlobInfo.newBuilder("bucketname",
 * "filename").setContentType("text/plain").build();
 * storage.createFrom(blobInfo, inputStreamFromRemote);
 * storage.downloadTo(BlobId.of("bucketName", "blobName"), Path.of(""));
 * 
 * channelSftp.put(localDir, 0); return true; }
 * 
 * }
 */