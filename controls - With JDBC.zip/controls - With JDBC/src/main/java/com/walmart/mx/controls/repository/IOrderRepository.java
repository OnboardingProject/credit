package com.walmart.mx.controls.repository;

import org.springframework.stereotype.Repository;

import com.google.cloud.spring.data.spanner.repository.SpannerRepository;
import com.google.cloud.spring.data.spanner.repository.query.Query;
import com.walmart.mx.controls.entity.Order;

@Repository
public interface IOrderRepository extends SpannerRepository<Order, String> {
	
	@Query(value = "SELECT NEXT VALUE FROM seq_credit_sales1", dmlStatement =  true)
    Long getNextSequenceValue();

}
