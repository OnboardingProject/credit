package com.walmart.mx.controls.controller;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.connection.Connection;
import com.google.cloud.spring.data.spanner.core.SpannerTemplate;
import com.walmart.mx.controls.entity.Order;
import com.walmart.mx.controls.repository.IOrderRepository;

@RestController
public class OrderController {

	@Autowired
	private IOrderRepository orderRepository;
	
	@Autowired
	private SpannerTemplate temp;

	@GetMapping("/api/orders/{id}")
	public Order getOrder(@PathVariable String id) throws SQLException {
		
		Order data=null;
		 
		try {
			//Seque
			data=orderRepository.findById(id).orElse(null);
			String connectionUrl =
			        String.format(
			            "jdbc:cloudspanner:/projects/%s/instances/%s/databases/%s;credentials=C:\\Users\\Hari\\Desktop\\controls\\src\\main\\resources\\august-terminus-399810-554edd9ae600.json",
			            "august-terminus-399810", "credit", "credito_db");
		 java.sql.Connection connection = DriverManager.getConnection(connectionUrl);
			Order order=new Order();
			order.setDescription("Hari");
			//order.setId(orderRepository.getNextSequenceValue());
			//order.setTimestamp(new Date());
			PreparedStatement ps =connection.prepareStatement("insert into credit_sales1(description) values(?)");
			ps.setString(1, "test123");
			ps.execute();
			//orderRepository.save(order);
		} catch (Exception e) {
			e.printStackTrace();
		}		
		
		return data;
	}

}
