package com.walmart.mx.controls.config;

public class CommonConfig {

}
