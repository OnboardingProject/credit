package com.walmart.mx.controls;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MxCreditoControlsApplicationTests {

	@Test
	void contextLoads() {
	}

}
